#include "Player.h"

Player::Player(Piece::PieceColor piecesColor)
{
	this->piecesColor = piecesColor;
}

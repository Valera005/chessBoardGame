#include "Game.h"



int main()
{
    Game game;

    game.Run();

    return 0;
}